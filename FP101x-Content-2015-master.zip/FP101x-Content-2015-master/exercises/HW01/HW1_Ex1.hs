{-
 -- original statement
 N = a 'div' length xs
	where
		a = 10
		xs = [1,2,3,4,5]
-}


{-
-- answer a
N = a `div` length xs
  where	a = 10
        xs = [1,2,3,4,5]

-}

 {-
-- answer b
n =  a 'div' length xs
    where
         a = 10
        xs = [1, 2, 3, 4, 5]
-}

 {- 
-- answer c
n = a `div` length xs
where
     a  = 10
     xs = [1, 2, 3, 4, 5]
-}

{-
-- answer d
n = a `div` length xs
    where a = 10
          xs = [1,2,3,4,5]
-}
