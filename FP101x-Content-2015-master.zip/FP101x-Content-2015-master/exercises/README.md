#Disclaimer

The code for the homework exercises is provided in these sub folders. Note however, that this code can contain typo's and **YOU** are responsible for checking whether the code you take from here, corresponds to the question / answers as displayed in the MooC. If you find an error, feel free to do a pull request with the correction.

Additionally, you should not just load and run these codes, but rather retype. Here is why: http://xion.io/post/programming/dont-copy-paste-retype.html
